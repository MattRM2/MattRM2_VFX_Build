# MattRM2 Qt Tools — Tutorial Examples

The complete code of the three tutorials in the **Qt Tools — The Basics** guide
(`MattRM2_Qt_Guide_Beginner_EN.pdf`), ready to use. No copy-paste from the PDF needed.

Requires the **MattRM2 VFX Build** (the Qt bridge and PySide6 are bundled and load by themselves).

## 01 — Hello World (`01_hello_world/`)

A single tool script, launched from Blender's **Python Console**:

```python
import mattrm2_qt_bridge as qt
qt.launch_tool(r"C:\path\to\01_hello_world\my_first_tool.py")
```

## 02 — Output panel (`02_output_panel/`)

A Qt window for the Output settings, plus an add-on that opens it from a button.

1. **Edit > Preferences > Add-ons > Install from Disk…** and pick `my_output_panel.zip`.
2. Enable **My Output Panel (Qt)**.
3. 3D Viewport > **N** > **My Tools** tab > **Open Output Panel**.

## 03 — Suzanne Express (`03_suzanne_express/`)

A Qt window with an action button that builds a subdivided, smooth, orange Suzanne in Blender.

1. **Edit > Preferences > Add-ons > Install from Disk…** and pick `suzanne_express.zip`.
2. Enable **Suzanne Express (Qt)**.
3. 3D Viewport > **N** > **My Tools** tab > **Open Suzanne Express**, then click **Build Suzanne**.

## Good to know

- Install the **`.zip`** files, not the folders. Each zip holds one folder containing an
  `__init__.py` (the add-on) and the Qt window script next to it. Both must stay together.
- Examples 02 and 03 both add a **My Tools** tab: with both enabled, the tab shows two panels.
- If a window does not open, check **Window > Toggle System Console** for the error message.
