bl_info = {
    "name": "My Output Panel (Qt)",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > N-panel > My Tools",
    "category": "Render",
}

import os, bpy

_THIS_DIR  = os.path.dirname(os.path.abspath(__file__))
_QT_SCRIPT = os.path.join(_THIS_DIR, "output_tool.py")

def _get_bridge():
    try:
        import mattrm2_qt_bridge as bridge
        return bridge if bridge.available() else None
    except Exception:
        return None

class WM_OT_my_output(bpy.types.Operator):
    bl_idname = "wm.my_output_panel"
    bl_label  = "Open Output Panel"

    def execute(self, context):
        bridge = _get_bridge()
        if bridge is None:
            self.report({'ERROR'}, "Qt bridge not available.")
            return {'CANCELLED'}
        bridge.launch_tool(_QT_SCRIPT)
        return {'FINISHED'}

class VIEW3D_PT_my_output(bpy.types.Panel):
    bl_label       = "My Tools"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "My Tools"

    def draw(self, context):
        self.layout.operator("wm.my_output_panel", icon="WINDOW")

_classes = (WM_OT_my_output, VIEW3D_PT_my_output)

def register():
    for c in _classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(_classes):
        bpy.utils.unregister_class(c)
