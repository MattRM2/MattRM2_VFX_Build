"""Tutorial 2 — the Qt window of the "Output" panel.

Launched by the add-on in __init__.py (N-panel > My Tools > Open Output Panel).
It can also be launched on its own from the Python Console:

    import mattrm2_qt_bridge as qt
    qt.launch_tool(r"C:\\path\\to\\output_tool.py")
"""
from mattrm2_qt_sdk import run_control_panel

run_control_panel(
    "Image Output",
    layout=[
        ("Dimensions", [
            ("Resolution X", "scene.render.resolution_x"),
            ("Resolution Y", "scene.render.resolution_y"),
            ("Scale (%)",    "scene.render.resolution_percentage"),
            ("Frame rate",   "scene.render.fps"),
        ]),
        ("Output File", [
            ("Output path", "scene.render.filepath"),
            ("Format",      "scene.render.image_settings.file_format"),
            ("Color mode",  "scene.render.image_settings.color_mode"),
            ("Color depth", "scene.render.image_settings.color_depth"),
        ]),
        ("Options", [
            ("Overwrite",      "scene.render.use_overwrite"),
            ("File extension", "scene.render.use_file_extension"),
            ("Placeholders",   "scene.render.use_placeholder"),
        ]),
    ],
)
