"""Tutorial 3 — the Qt window with an action button.

Launched by the add-on in __init__.py (N-panel > My Tools > Open Suzanne Express).
The "build_suzanne" handler it calls is registered by that add-on.
"""
import sys, json, argparse
from PySide6 import QtWidgets, QtCore, QtNetwork
from mattrm2_qt_sdk import THEME_QSS

class Tool(QtWidgets.QWidget):
    def __init__(self, port):
        super().__init__()
        self.setWindowTitle("Suzanne Express")
        self.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, True)
        self.setStyleSheet(THEME_QSS)
        self._buf = b''
        root = QtWidgets.QVBoxLayout(self)
        title = QtWidgets.QLabel("Suzanne Express")
        title.setObjectName("title")
        self.status = QtWidgets.QLabel("Connecting to Blender...")
        self.status.setObjectName("muted")
        self.btn = QtWidgets.QPushButton("Build Suzanne")
        self.btn.setEnabled(False)
        self.btn.clicked.connect(self._build)
        root.addWidget(title)
        root.addWidget(self.status)
        root.addWidget(self.btn)
        self.sock = QtNetwork.QTcpSocket(self)
        self.sock.readyRead.connect(self._on_read)
        self.sock.connected.connect(self._on_connect)
        self.sock.disconnected.connect(self.close)
        self.sock.connectToHost("127.0.0.1", int(port))

    def _on_connect(self):
        self.status.setText("Connected to Blender - ready")
        self.btn.setEnabled(True)

    def _build(self):
        self.status.setText("Building...")
        msg = {"op": "call", "target": "build_suzanne", "args": {}, "id": 1}
        self.sock.write((json.dumps(msg) + "\n").encode("utf-8"))

    def _on_read(self):
        self._buf += bytes(self.sock.readAll())
        while b"\n" in self._buf:
            line, _, self._buf = self._buf.partition(b"\n")
            if not line.strip():
                continue
            msg = json.loads(line.decode("utf-8"))
            if msg.get("op") == "result":
                self.status.setText("Done: " + str(msg.get("value")))

ap = argparse.ArgumentParser()
ap.add_argument("--port", type=int, required=True)
args, _ = ap.parse_known_args()
app = QtWidgets.QApplication(sys.argv)
win = Tool(args.port)
win.show()
sys.exit(app.exec())
