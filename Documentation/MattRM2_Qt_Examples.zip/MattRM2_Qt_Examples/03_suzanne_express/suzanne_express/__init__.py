bl_info = {
    "name": "Suzanne Express (Qt)",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > N-panel > My Tools",
    "category": "Object",
}

import os, bpy

_THIS_DIR  = os.path.dirname(os.path.abspath(__file__))
_QT_SCRIPT = os.path.join(_THIS_DIR, "actions_tool.py")

def build_suzanne(args):
    # 1. Create Suzanne
    bpy.ops.mesh.primitive_monkey_add()
    obj = bpy.context.active_object
    obj.name = "Suzanne"

    # 2. Subdivision Surface modifier, level 2
    mod = obj.modifiers.new(name="Subdivision", type="SUBSURF")
    mod.levels        = 2   # in the 3D view
    mod.render_levels = 2   # at render

    # 3. Shade smooth: mark every face as smooth
    for poly in obj.data.polygons:
        poly.use_smooth = True

    # 4. Orange Principled BSDF material (#FB923C)
    mat = bpy.data.materials.new(name="Matt Orange")
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.965, 0.287, 0.045, 1.0)
    obj.data.materials.clear()
    obj.data.materials.append(mat)

    return obj.name

def _get_bridge():
    try:
        import mattrm2_qt_bridge as bridge
        return bridge if bridge.available() else None
    except Exception:
        return None

class WM_OT_suzanne(bpy.types.Operator):
    bl_idname = "wm.suzanne_express"
    bl_label  = "Open Suzanne Express"
    def execute(self, context):
        bridge = _get_bridge()
        if bridge is None:
            self.report({'ERROR'}, "Qt bridge not available.")
            return {'CANCELLED'}
        bridge.launch_tool(_QT_SCRIPT)
        return {'FINISHED'}

class VIEW3D_PT_suzanne(bpy.types.Panel):
    bl_label       = "My Tools"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "My Tools"
    def draw(self, context):
        self.layout.operator("wm.suzanne_express", icon="MONKEY")

_classes = (WM_OT_suzanne, VIEW3D_PT_suzanne)

def register():
    for c in _classes:
        bpy.utils.register_class(c)
    bridge = _get_bridge()
    if bridge:
        bridge.register_handler("build_suzanne", build_suzanne)

def unregister():
    bridge = _get_bridge()
    if bridge:
        bridge.unregister_handler("build_suzanne")
    for c in reversed(_classes):
        bpy.utils.unregister_class(c)
