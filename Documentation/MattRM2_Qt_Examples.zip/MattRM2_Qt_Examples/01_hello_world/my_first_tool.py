"""Tutorial 1 — "Hello World": the smallest Qt tool wired to Blender.

Launch it from Blender's Python Console (adjust the path to this file):

    import mattrm2_qt_bridge as qt
    qt.launch_tool(r"C:\\path\\to\\my_first_tool.py")
"""
from mattrm2_qt_sdk import run_control_panel

run_control_panel(
    "My First Tool",
    layout=[
        ("Image", [
            ("Width (px)",          "scene.render.resolution_x"),
            ("Transparent film",    "scene.render.film_transparent"),
        ]),
    ],
)
